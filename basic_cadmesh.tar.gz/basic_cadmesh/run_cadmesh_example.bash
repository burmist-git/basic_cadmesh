#!/bin/bash

########################################################################
#                                                                      #
# Copyright(C) 2018 - LBS - (Single person developer.)                 #
# Thu Oct 11 11:17:20 JST 2018                                         #
# Autor: Leonid Burmistrov                                             #
#                                                                      #
# File description:                                                    #
#                                                                      #
#                                                                      #
# Input paramete:                                                      #
#                                                                      #
# This software is provided "as is" without any warranty.              #
#                                                                      #
########################################################################

function compileG4 {

    echo "compileG4"
    make -j8

}

function reCompileG4 {

    echo "compileG4"
    make clean;
    make -j8

} 

function bashtemplate_bash {

    
    echo "bashtemplate_bash"
    ./cadmesh_example $1 $2
    #DIR="$( dirname $2)"
    infilename="$( basename $2)"
    echo $infilename;
    mv 'tessellatedSolidVertices.dat' $infilename'.dat'
    mv 'tessellatedSolidVertices.xml' $infilename'.xml'
    mv 'G4Data0.heprep' 'G4Data0_'$infilename'.heprep'
    
}

function printHelp {

    echo " --> ERROR in input arguments "
    echo " -d : default"
    echo " -c : compile"
    echo " -r : re-compile"

}

if [ $# -eq 0 ] 
then
    
    printHelp
    
else
    
    if [ "$1" = "-d" ]; then
	
        visFile="./macros/vis_heprep.mac"
	#fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/ddd.ply"
	#fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/rr.stl"
	#3DSMaxExport.STL  formatDetection  sphereWithHole.stl  Spider_ascii.stl  Spider_binary.stl  triangle.stl  Wuson.stl
	#fileWithMesh="/home/burmist/CADMesh_v1.1/CADMesh/external/assimp/test/models/STL/sphereWithHole.stl"
	#cube.ply  pond.0.ply  Wuson.ply
	#fileWithMesh="/home/burmist/CADMesh_v1.1/CADMesh/external/assimp/test/models/PLY/cube.ply"
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_01.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_02.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_03.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_04.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_05.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_06.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_07.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_08.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_09.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_10.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_11.stl"
	bashtemplate_bash $visFile $fileWithMesh
	fileWithMesh="/home/burmist/home2/freecad/2018-08-24-Ensemble_secteur_ARICH/2018-08-24_ARICH_merger_cooling_bodys/2018-08-24_ARICH_merger_cooling_body_12.stl"
	bashtemplate_bash $visFile $fileWithMesh
	
    elif [ "$1" = "-c" ]; then
	
	compileG4

    elif [ "$1" = "-r" ]; then
	
	reCompileG4

    else
        
        printHelp
            
    fi
   
fi
