
TPolyLine3D *buildTriangle( double *x, double *y, double *z);

void triangle3d(){

  TCanvas *c1 = new TCanvas("c1","PolyLine3D & PolyMarker3D Window",200,10,700,500);
  
  // creating a view
  TView *view = TView::CreateView(1);

  view->SetRange(-5,-5,-5,5,5,5);
  double appx[3] = {0.0,1.0,0.0};
  double appy[3] = {0.0,0.0,0.0};
  double appz[3] = {0.0,0.0,1.0};
    
  TPolyLine3D *pl3d1 = buildTriangle(appx,appy,appz);
  pl3d1->Draw();
  
}

TPolyLine3D *buildTriangle( double *x, double *y, double *z){
  TPolyLine3D *tr = new TPolyLine3D(3);
  for(Int_t i = 0;i<3;i++)
    tr->SetPoint(i, x[i], y[i], z[i]);
  tr->SetPoint(3, x[0], y[0], z[0]);
  tr->SetLineWidth(3);
  tr->SetLineColor(kBlack);
  return tr;
}
