/* ************************************************
 * GEANT4 VCGLIB/CAD INTERFACE - basic example
 *
 * File:      DetectorConstruction.cc
 *
 * Author:    Christopher M Poole,
 * Email:     mail@christopherpoole.net
 *
 * Date:      20th March, 2011
 **************************************************/

// USER //
#include "DetectorConstruction.hh"

// CADMESH //
#include "CADMesh.hh"

// GEANT4 //
#include "globals.hh"
#include "G4ThreeVector.hh"
#include "G4Transform3D.hh"

#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4AssemblyVolume.hh"

#include "G4NistManager.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

// VGM demo //
//#include "Geant4GM/volumes/Factory.h"
//#include "RootGM/volumes/Factory.h"
//#include "TGeoManager.h"

// my //
#include "libxmlarichdata.h"
#include "cellStr.h"
#include "tessellatedSolidStr.h"

// c, c++ //
#include <vector>

DetectorConstruction::DetectorConstruction()
{
    filename = "";
    filetype = "";
}

DetectorConstruction::~DetectorConstruction()
{
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{

    xmlarichdata::quartz_Babar_DIRC_polishing_quality_bounds();
    G4NistManager * nist_manager = G4NistManager::Instance();
    G4Material * air = nist_manager->FindOrBuildMaterial("G4_AIR");
    G4Material * water = nist_manager->FindOrBuildMaterial("G4_WATER");

    //world_solid = new G4Box("world_solid", 50*cm, 50*cm, 50*cm);
    world_solid = new G4Box("world_solid", 1000*cm, 100*cm, 100*cm);
    //world_solid = new G4Box("world_solid", 1*cm, 1*cm, 1*cm);
    world_logical = new G4LogicalVolume(world_solid, air,"world_logical",0,0,0);
    world_physical = new G4PVPlacement(0, G4ThreeVector(), world_logical,
                                       "world_physical", 0, false, 0);
    world_logical->SetVisAttributes(G4VisAttributes::Invisible);

    // CAD model rotation. 
    G4RotationMatrix * rot = new G4RotationMatrix();
    //rot->rotateZ(90*deg);
    rot->rotateZ(0*deg);
    
    // Load CAD file as tessellated solid //
    //offset = G4ThreeVector(-20*cm, 0, 0);
    //offset = G4ThreeVector(-7*cm, -5.0*cm, 0);
    //offset = G4ThreeVector(0.0*mm, 0.0*mm, 0.0*mm);
    offset = G4ThreeVector(0.0*mm, 0.0*mm, -0.308700*mm);
    
    Double_t zCompression = 1.0/17.0;
    //Double_t zCompression = 1.0;
    
    // Note that offset is applied to the points in mesh directly before placement.
    CADMesh * mesh = new CADMesh((char*) filename.c_str());
    G4cout<<"filename = "<<filename<<G4endl;
    mesh->SetScale(mm);
    mesh->SetOffset(offset);
    mesh->SetScaleXYZ(G4ThreeVector(1.0, 1.0, zCompression));
    mesh->SetReverse(false);

    cad_solid = mesh->TessellatedMesh();
    cad_logical = new G4LogicalVolume(cad_solid, water, "cad_logical", 0, 0, 0);
    cad_physical = new G4PVPlacement(rot, G4ThreeVector(), cad_logical,
                                     "cad_physical", world_logical, false, 0);
    cad_logical->SetVisAttributes(G4Color(0.5, 0.3, 1, 1));

    xmlarichdata::saveTessellatedSolidVerticesToXML( mesh->GetTessellatedSolidVertices(), 20, "tessellatedSolidVertices.xml");
    xmlarichdata::saveTessellatedSolidVerticesToDATfile( mesh->GetTessellatedSolidVertices(), 20, "tessellatedSolidVertices.dat");
    //tessellatedSolidStr tessellatedSolid = xmlarichdata::readTessellatedSolidVerticesToDATfile("tessellatedSolidVertices.dat");
    //tessellatedSolid.printInfo();
    //xmlarichdata::dumpTessellatedSolidVertices( mesh->GetTessellatedSolidVertices(),20);
    //std::vector<cellStr> tessellatedSolidVertices = mesh->GetTessellatedSolidVertices();
    //unsigned int i = 0;
    //for(i = 0; i<tessellatedSolidVertices.size();i++)
    //tessellatedSolidVertices[i].printInfo();
    
    if (filetype != "") { 
        // Load CAD file as tetrahedral mesh //
        CADMesh * tet_mesh = new CADMesh((char*) filename.c_str(), (char*) filetype.c_str());
        tet_mesh->SetScale(1.5);
	//tet_mesh->SetScale(1.0);
	tet_mesh->SetScaleXYZ(G4ThreeVector(1.0, 1.0, zCompression));
        tet_mesh->SetMaterial(water); // We have to do this before making the G4AssemblyVolume.

        G4AssemblyVolume * cad_assembly = tet_mesh->TetrahedralMesh();

        //G4Translate3D translation(20*cm, 0., 0.);
	G4Translate3D translation(0, 0., 0.);
        G4Transform3D rotation = G4Rotate3D(*rot);
        G4Transform3D transform = translation*rotation;

        cad_assembly->MakeImprint(world_logical, transform, 0, 0);
    }

    /*
    // ---------------------------------------------------------------------------                                                                                       
    // VGM demo                                                                                                                                                          
    // Export geometry in Root and save it in a file                                                                                                                     
    //                                                                                                                                                                   
    //                                                                                                                                                                   
    // Import Geant4 geometry to VGM                                                                                                                                     
    Geant4GM::Factory g4Factory;
    g4Factory.SetDebug(1);
    g4Factory.Import(world_physical);
    //                                                                                                                                                                   
    
    // Export VGM geometry to Root                                                                                                                                       
    RootGM::Factory rtFactory;
    rtFactory.SetDebug(1);
    g4Factory.Export(&rtFactory);
    gGeoManager->CloseGeometry();
    gGeoManager->Export("geometry.root");
    
    //                                                                                                                                                                   
    // end VGM demo                                                                                                                                                      
    //---------------------------------------------------------------------------              
    */
    
    return world_physical;
}
